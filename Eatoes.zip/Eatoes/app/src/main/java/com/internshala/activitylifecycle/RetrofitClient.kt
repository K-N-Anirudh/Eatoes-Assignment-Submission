package com.internshala.activitylifecycle

import android.util.Log
import android.view.Display
import okhttp3.OkHttpClient
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

object ServiceBuilder {
    private val client = OkHttpClient.Builder().build()

    private val retrofit = Retrofit.Builder()
        .baseUrl("https://reqres.in/api/")
        .addConverterFactory(GsonConverterFactory.create())
        .client(client)
        .build()

    fun<T> buildService(service: Class<T>): T{
        return retrofit.create(service)
    }
}

class RestApiService {
    fun login(userData: UserInfo, onResult: (Model?) -> Unit){
        val retrofit = ServiceBuilder.buildService(Api::class.java)
        retrofit.login(userData).enqueue(
            object : Callback<Model> {
                override fun onResponse(call: Call<Model>, response: Response<Model>) {
                    val res:Model? = response.body()
                    Log.d("HHH",response.toString())
                    onResult(res)
                }

                override fun onFailure(call: Call<Model>, t: Throwable) {
                    onResult(null)
                }

            }
        )
    }
}