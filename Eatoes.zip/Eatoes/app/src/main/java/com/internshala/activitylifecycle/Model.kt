package com.internshala.activitylifecycle




    // To parse the JSON, install kotlin's serialization plugin and do:
//
// val json       = Json(JsonConfiguration.Stable)
// val eatoesJSON = json.parse(EatoesJSON.serializer(), jsonString)




    data class Model (
       val token:String
    )


    data class Datum (
        val id: Long,
        val name: String,
        val year: Long,
        val color: String,

        val pantone_value: String
    )


    data class Support (
        val url: String,
        val text: String
    )

