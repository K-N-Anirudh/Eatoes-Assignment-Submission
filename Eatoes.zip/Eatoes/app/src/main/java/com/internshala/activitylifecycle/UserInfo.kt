package com.internshala.activitylifecycle

data class UserInfo(
    val email:String,
    val password:String
)
