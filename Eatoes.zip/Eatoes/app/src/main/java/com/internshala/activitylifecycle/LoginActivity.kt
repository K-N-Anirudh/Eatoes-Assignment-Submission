package com.internshala.activitylifecycle


import android.content.Intent
import android.os.Bundle
import android.provider.ContactsContract
import android.support.v7.app.AppCompatActivity
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_home.*

class LoginActivity : AppCompatActivity() {

    private lateinit var etEmail: EditText
    private lateinit var etPassword: EditText
    private lateinit var btnLogin: Button
    private lateinit var txtForgotPassword: TextView
    private lateinit var txtRegisterYourself: TextView




    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)


        val isLoggedIn = false

        setContentView(R.layout.activity_login)

        if (isLoggedIn) {
            val intent = Intent(this@LoginActivity, HomeActivity::class.java)
            startActivity(intent)
            finish()
        }

        title = "Log In"

        etEmail = findViewById(R.id.etEmail)
        etPassword = findViewById(R.id.etPassword)
        btnLogin = findViewById(R.id.btnLogin)
        txtForgotPassword = findViewById(R.id.txtForgotPassword)
        txtRegisterYourself = findViewById(R.id.txtRegister)




        btnLogin.setOnClickListener {

            val Email = etEmail.text.toString()

            val password = etPassword.text.toString()


                val apiService = RestApiService()
                val userInfo = UserInfo(email = Email,password = password )

                apiService.login(userInfo) {
                    if (it != null) {
                        val intent = Intent(this@LoginActivity, HomeActivity::class.java)
                        intent.putExtra("email",Email)
                        intent.putExtra("token",it.token)
                        startActivity(intent)
                    } else {
                        Log.d("HHH","Error logging new user")
                    }
                }








        }


        txtForgotPassword.setOnClickListener {
            val intent = Intent(this@LoginActivity, ForgotPasswordActivity::class.java)
            startActivity(intent)
        }



    }

    override fun onPause() {
        super.onPause()
        finish()
    }

}


