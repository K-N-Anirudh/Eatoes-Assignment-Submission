package com.internshala.activitylifecycle

import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST


interface Api {
    @POST("login")
    fun login(@Body userData: UserInfo):Call<Model>
}